Full modem wired and Full modem FOTA updates can be performed using the modem firmware in CBOR image
format, provided that you have the necessary support from the nRF Connect SDK and the device
hardware. The filename is as follows:
- mfw_nrf91x1_2.0.4.cbor

This release version includes delta update from the previous firmware version. The FOTA update
filename is as follows:
- mfw_nrf91x1_update_from_2.0.2_to_2.0.4.bin
- mfw_nrf91x1_update_from_2.0.3_to_2.0.4.bin

Additionally, this release includes FOTA-TEST delta update images between the original firmware and
the FOTA-TEST image. The FOTA test update filenames are as follows:
- mfw_nrf91x1_update_from_2.0.4_to_2.0.4-FOTA-TEST
- mfw_nrf91x1_update_from_2.0.4-FOTA-TEST_to_2.0.4
- mfw_nrf91x1_large_update_from_2.0.4_to_2.0.4-FOTA-TEST.bin
- mfw_nrf91x1_large_update_from_2.0.4-FOTA-TEST_to_2.0.4.bin
 
UUID of mfw_nrf91x1_2.0.4 is 11866dbb-3d51-4226-8098-59dc6b9b5a50
UUID of mfw_nrf91x1_2.0.4-FOTA-TEST is 8a5ea888-67f6-432a-8fb5-f5476b771fe0