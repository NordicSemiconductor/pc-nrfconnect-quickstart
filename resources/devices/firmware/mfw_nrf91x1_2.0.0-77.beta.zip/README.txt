Non-wired full modem update can be performed by using CBOR image format and suitable support from
the nRF Connect SDK and device hardware. Content of the CBOR files firmware.update.image.cbor and
mfw_nrf91x1_2.0.0-77.beta.cbor are identical, and only the latter naming will be used in the
following release versions.

This release includes FOTA-TEST images between mfw_nrf91x1_2.0.0-77.beta release firmware and
mfw_nrf91x1_2.0.0-77.beta-FOTA-TEST test firmware. FOTA test update filenames are the following
- mfw_nrf91x1_update_from_2.0.0-77.beta_to_2.0.0-77.beta-FOTA-TEST
- mfw_nrf91x1_update_from_2.0.0-77.beta-FOTA-TEST_to_2.0.0-77.beta
- mfw_nrf91x1_large_update_from_2.0.0-77.beta_to_2.0.0-77.beta-FOTA-TEST.bin
- mfw_nrf91x1_large_update_from_2.0.0-77.beta-FOTA-TEST_to_2.0.0-77.beta.bin

UUID of mfw_nrf91x1_2.0.0-77.beta is 4f98600b-a3d2-4153-8f92-b44eeb19ee90
UUID of mfw_nrf91x1_2.0.0-77.beta-FOTA-TEST is c2acfb7e-e13b-4b8c-a95f-8357a6e2b1cc