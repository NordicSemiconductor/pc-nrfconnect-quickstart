Full modem wired and Full modem FOTA updates can be performed using the modem firmware in CBOR image
format, provided that you have the necessary support from the nRF Connect SDK and the device
hardware. The filename is as follows:
- mfw_nrf91x1_2.0.0.cbor
 
This release includes FOTA-TEST delta update images between the original firmware and the FOTA-TEST
image. The FOTA test update filenames are as follows:
- mfw_nrf91x1_update_from_2.0.0_to_2.0.0-FOTA-TEST
- mfw_nrf91x1_update_from_2.0.0-FOTA-TEST_to_2.0.0
- mfw_nrf91x1_large_update_from_2.0.0_to_2.0.0-FOTA-TEST.bin
- mfw_nrf91x1_large_update_from_2.0.0-FOTA-TEST_to_2.0.0.bin
 
UUID of mfw_nrf91x1_2.0.0 is c234531b-9f14-4135-9092-f4e52d37fb23
UUID of mfw_nrf91x1_2.0.0-FOTA-TEST is 063869d2-e9e8-4d65-8ae2-265ab6985657